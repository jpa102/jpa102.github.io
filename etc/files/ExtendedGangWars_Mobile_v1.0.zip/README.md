[![AML Mod Compiler](https://github.com/AndroidModLoader/GTA_ExGangWars/actions/workflows/main.yml/badge.svg?branch=main)](https://github.com/AndroidModLoader/GTA_ExGangWars/actions/workflows/main.yml)

### What is this mod?

This is a port of a mod named "Extended Gang Wars" by SilentPL.

Original GtaForums link: https://gtaforums.com/topic/682194-extended-gang-wars/

### Description
```
San Andreas introduced gang wars to the series.
According to beta game screenshots and the game code, Rockstar at some point planned to allow the player to have wars with all gangs in game.
However, in retail game the player would only be able to take over Ballas' and Vagos' turfs.
This modification unlocks gang wars with all gangs (even the unused ones, if any modification makes use of them) so the player can quite literally take over an entire state.
```

### Credits
Original mod was made by SilentPL (SilentPatch, woohoo!)

Mod has been ported to the Android by AML community. Do not trust fake-ass kids they did this.